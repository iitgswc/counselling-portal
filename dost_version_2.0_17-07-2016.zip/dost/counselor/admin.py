from django.contrib import admin

from .models import notifications

admin.site.register(notifications)
