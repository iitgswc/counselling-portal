from django.apps import AppConfig


class QuotesConfig(AppConfig):
    name = 'quotes'
