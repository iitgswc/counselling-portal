from django.contrib import admin
from .models import comment

admin.site.register(comment)

# Register your models here.
