from django.apps import AppConfig


class FaqsConfig(AppConfig):
    name = 'faqs'
